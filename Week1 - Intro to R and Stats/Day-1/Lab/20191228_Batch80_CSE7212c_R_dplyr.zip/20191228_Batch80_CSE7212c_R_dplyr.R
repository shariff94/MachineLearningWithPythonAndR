#' 
#' ## Objective
#' 
#' The objective of this session is to get familiar with 'dplyr' library which makes woring with dataframes a lot easier and clean.
#' 
#' ## Key takeaways
#' 
#' Exploring the below functions in dplyr
#' 
#' 1. select() -	select columns
#' 
#' 2. filter() -	filter rows
#' 
#' 3. arrange() -	re-order or arrange rows
#' 
#' 4. mutate() -	create new columns
#' 
#' 5. summarise() -	summarise values
#' 
#' 6. group_by() -	allows for group operations in the "split-apply-combine" concept
#' 
#' 
#' ## 'dplyr' Package
#' Read the dataset.
#' 
msleep <- read.csv("msleep.csv")
head(msleep, 5)
dim(msleep)

# install.packages("dplyr")
library(dplyr)

#' ##
#' ### Function1: select
#' 
#' <!-- # Select specific columns -->
sleepData <- select(msleep, name, sleep_total)
head(sleepData)

#' 
# Select all, except specific solumns
head(select(msleep, -name))

#' 
# Look at the column names
names(msleep)

#' 
# Select a series of columns
head(select(msleep, name:order))

#' 
# Select columns starting with specific names
head(select(msleep, starts_with("sl")))

#' ##
#' ### Function2: filter
#' 
# Select rows w.r.t a particular column values
f1 = filter(msleep, sleep_total >= 16)
head(f1, 5)

#' 
# Select rows which satifty multiple conditions
f2 = filter(msleep, sleep_total >= 16, bodywt >= 1)
head(f2, 5)

#' 
# Select rows, according to specific values of an attribute
f3 = filter(msleep, order %in% c("Perissodactyla", "Primates"))
head(f3, 5)

#' 
#' ##
#' ### Function3: arrange
#' 
#' Arrange the rows according to specific order of an attribute
#' 
a1 = arrange(msleep, sleep_total)
head(a1, 5)
a2 = arrange(msleep, -sleep_total)
head(a2, 5)
a3 = arrange(msleep, order, sleep_total)
head(a3, 5)
a4 = arrange(msleep, desc(order), sleep_total)
head(a4, 5)

#' ##
#' ### Function4: mutate
#' 
# Create a new column using other columns
m1 = mutate(msleep, rem_proportion = sleep_rem / sleep_total)
head(m1, 5)

#' 
m2 = mutate(msleep, rem_proportion = sleep_rem / sleep_total, 
       bodywt_grams = bodywt * 1000)
head(m2, 5)

#' ##
#' ### Function5: summarise
#' <!-- # Find summary of columns -->
#' 
msleep
names(msleep)
summarise(msleep, avg_sleep = mean(sleep_total))
msleep %>% group_by(vore) %>% summarise(avg_sleep = mean(sleep_total))

#' 
summarise(msleep, 
          avg_sleep = mean(sleep_total), 
          min_sleep = min(sleep_total),
          max_sleep = max(sleep_total),
          total = n())

#' ##
#' ### Function6: Group_by
#' <!-- # Summarize data by levels in an attribute -->
#' 
a = summarise(group_by(msleep, order), 
          avg_sleep = mean(sleep_total), 
          min_sleep = min(sleep_total), 
          max_sleep = max(sleep_total),
          total = n())

#' 
#' ##
#' ### Function7: Chaining
#' <!-- # Call multiple functions in a single go -->
#' 
msleep %>%
  select(name, sleep_total) %>%
  head

#' 
msleep %>%
  select(name, order, sleep_total) %>%
  arrange(order, sleep_total) %>%
  head

#' 
msleep %>%
  group_by(order) %>%
  summarise(avg_sleep = mean(sleep_total),
            min_sleep = min(sleep_total),
            max_sleep = max(sleep_total),
            total = n())

#' ##
#' ## Excercise
#' 
#' Load mtcars dataset into R and solve the following using dplyr functions
#' 
#' 1. Create a dataframe which has columns 'mpg', 'cyl', 'disp', 'hp', 'drat', 'wt', 'qsec', 'vs', 'am', 'gear'
#' 
#' 2. Subset the dataframe which has cars with mpg above 20
#' 
#' 3. Create a new column which gives hp/wt ratio
#' 
#' 4. What is the mean hp/wt ratio of manual and automatic transmission cars
#' 
#' 5. Perform all the above steps using chaining operation 
